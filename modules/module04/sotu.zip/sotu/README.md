# State of the Union Corpus (1790-2019)

This data was obtained from the [State of the Union Corpus (1790-2018)]. The
text of the 2019 State of the Union address was downloaded by copy/pasting the
text found at [Bloomberg] on February 17, 2019.

Ed Summers <ehs@pobox.com>

[State of the Union Corpus (1790-2018)]: https://www.kaggle.com/rtatman/state-of-the-union-corpus-1989-2017/version/3k
[Bloomberg]: https://www.bloomberg.com/news/articles/2019-02-06/text-of-president-donald-trump-s-state-of-the-union-address
